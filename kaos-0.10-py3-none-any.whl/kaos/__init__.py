#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Oct  9 14:12:55 2023

@author: abhishek
"""

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Jul 13 22:43:10 2023

@author: abhishekh
"""

import numpy as np
import re


        
class Read():

    def read_fasta_removing_non_atgc(self, file_path: str):
        from Bio import SeqIO
        counter = 0
        sequence = ""
        
        for record in SeqIO.parse(file_path, "fasta"):

            sequence = sequence + str(record.seq)  
            counter+=1

        return re.sub(r'[^ATGC]', '', sequence, flags=re.IGNORECASE).upper()
    
    def read_fasta_with_non_atgc(self, file_path: str):
        
        from Bio import SeqIO
        counter = 0
        sequence = ""
        
        for record in SeqIO.parse(file_path, "fasta"):

            sequence = sequence + str(record.seq)  
            counter+=1

        return sequence.upper()
    
    def generate_random_sequence(self, length: int):
        import random
        valid_chars = ['A', 'T', 'G', 'C']
        sequence = ''.join(random.choice(valid_chars) for _ in range(length))
        return sequence
    
        
    def complement_dna_sequence(self, sequence: str):
        complement = {
            'A': 'T',
            'T': 'A',
            'C': 'G',
            'G': 'C'
        }
        return ''.join(complement.get(base) for base in sequence)
    

    
    

   
class kaos_fcgr():
    
    # def __init(self):
        
    def return_kmer_count(self,sequence:str, kmer_length:int):

        from collections import defaultdict
        kmer_counts = defaultdict(int)  
        for i in range(len(sequence) - kmer_length + 1):
            kmer = sequence[i:i + kmer_length]
            kmer_counts[kmer] += 1
        return dict(kmer_counts)
    
    def chaos_game_representation_key(self, kmer_length:int):
        
        import numpy as np
        import sys
        
        if isinstance(kmer_length, int)==False:    
            sys.exit("The k-mer length is not valid. Please provide a integer k-mer value.")
        if kmer_length<1:    
                sys.exit("The k-mer length cannot be less than 1.")
                
        row = col = np.power(2,kmer_length)
        
        arr = np.empty((row, col), dtype=object)
        arr.fill('')
        
        arr[0:(row//2), 0:(col//2)] = "C"
        arr[0:(row//2), (col//2):col] = "G"
        arr[(row//2):row, 0:(col//2)] = "A"
        arr[(row//2):row, (col//2):col] = "T"
        
        bth = arr.copy()
        
        for i in range(kmer_length-1):
            
            bth = bth.reshape(row,row//2,2).transpose(2, 0, 1).reshape((row, col))
            arr = np.array([x + y for x, y in zip(arr.flatten(), bth.flatten())]).reshape(arr.shape)
            
        return arr
    
    def return_fcgr_matrix(self, fasta_string: str, kmer_length: int, chaos_game_kmer_array: np.array=None, return_key_matrix: bool = False,  pseudo_count = True, return_probability_fcgr_dictionary=False, return_actual_fcgr_dictionary=False):
        
        import numpy as np
        import sys
        import pandas as pd
        
        if isinstance(kmer_length, int)==False:    
            sys.exit("The k-mer length is not valid. Please provide a integer k-mer value.")
            
        if kmer_length<1:    
            sys.exit("The k-mer length cannot be less than 1.")
        # if isinstance(fasta_string, str)==False:
            sys.exit("The fasta string contain non string value. It should contain only string.")
            
        fasta_string = fasta_string.upper()
              
        if len(set(list(fasta_string)))>4:
            sys.exit("The file has more than 4 unique value. Present model works only for 4 unique character.")
            
        if not (set(list(set(list(fasta_string)))).issubset(['G', 'T', 'A', 'C'])):
            sys.exit("The file charcater other than A, T, G, C. So we are exiting.")
       
            
        if kmer_length<1:    
                sys.exit("The k-mer length cannot be less than 1.")
                
        if chaos_game_kmer_array is None:
            chaos_game_kmer_array = self.chaos_game_representation_key(kmer_length)
                

        rows = np.power(2, kmer_length)
        
        fcgr_sequence = self.return_kmer_count(fasta_string, kmer_length=kmer_length)
        
        fcgr_sequence_lookup = {k.upper(): v for k, v in fcgr_sequence.items()}
        
        matrix2 = np.zeros((rows, rows))
        
        for (i, j), value in np.ndenumerate(chaos_game_kmer_array):
            upper_value = value.upper()
            if upper_value in fcgr_sequence_lookup:
                matrix2[i, j] = fcgr_sequence_lookup[upper_value]
                
        if pseudo_count==True:
            matrix2 = (matrix2 + np.ones((matrix2.shape[0],matrix2.shape[1])))
            
        if return_actual_fcgr_dictionary==True:           

            avg_prob_df = pd.DataFrame(columns = ["kmer", "Probability"])
            avg_prob_df["kmer"] = chaos_game_kmer_array.ravel()
            avg_prob_df["Freq"] = matrix2.ravel()
        
            avg_prob_dictionary_frequency = {key: value for key, value in zip(avg_prob_df['kmer'], avg_prob_df['Freq'])}
            
            return avg_prob_dictionary_frequency
            
        if return_probability_fcgr_dictionary==True:           
            seq_fcgr_list = list()
            seq_fcgr_list.append(matrix2)
            
            prob_all_amr = [outer/sum(np.array(outer).ravel()) for outer in seq_fcgr_list]
            avg_prob_amr = np.sum(prob_all_amr, axis=0)/len(prob_all_amr)
            avg_prob_df = pd.DataFrame(columns = ["kmer", "Probability"])
            avg_prob_df["kmer"] = chaos_game_kmer_array.ravel()
            avg_prob_df["Probability"] = avg_prob_amr.ravel()
        
            avg_prob_dictionary = {key: value for key, value in zip(avg_prob_df['kmer'], avg_prob_df['Probability'])}
            
            return avg_prob_dictionary
                
        if return_key_matrix==True:
            return matrix2, chaos_game_kmer_array
        else:
            del chaos_game_kmer_array
            return matrix2
        
        
    def chaos_frequency_matrix(self, fasta_string: str, kmer_length: int, chaos_game_kmer_array: np.array=None,  pseudo_count = True):

        import numpy as np
        import sys
        import pandas as pd

        if isinstance(kmer_length, int)==False:    
            sys.exit("The k-mer length is not valid. Please provide a integer k-mer value.")

        if kmer_length<1:    
            sys.exit("The k-mer length cannot be less than 1.")
        # if isinstance(fasta_string, str)==False:
            sys.exit("The fasta string contain non string value. It should contain only string.")

        fasta_string = fasta_string.upper()

        if len(set(list(fasta_string)))>4:
            sys.exit("The file has more than 4 unique value. Present model works only for 4 unique character.")

        if not (set(list(set(list(fasta_string)))).issubset(['G', 'T', 'A', 'C'])):
            sys.exit("The file charcater other than A, T, G, C. So we are exiting.")


        if kmer_length<1:    
                sys.exit("The k-mer length cannot be less than 1.")

        if chaos_game_kmer_array is None:
            chaos_game_kmer_array = self.chaos_game_representation_key(kmer_length)


        rows = np.power(2, kmer_length)

        fcgr_sequence = self.return_kmer_count(fasta_string, kmer_length=kmer_length)

        fcgr_sequence_lookup = {k.upper(): v for k, v in fcgr_sequence.items()}

        matrix2 = np.zeros((rows, rows))

        for (i, j), value in np.ndenumerate(chaos_game_kmer_array):
            upper_value = value.upper()
            if upper_value in fcgr_sequence_lookup:
                matrix2[i, j] = fcgr_sequence_lookup[upper_value]

        if pseudo_count==True:
            matrix2 = (matrix2 + np.ones((matrix2.shape[0],matrix2.shape[1])))

        return matrix2, chaos_game_kmer_array
    
    def chaos_frequency_dictionary(self, fasta_string: str, kmer_length: int, chaos_game_kmer_array: np.array=None, pseudo_count = True):
        
        import numpy as np
        import sys
        import pandas as pd
        
        if isinstance(kmer_length, int)==False:    
            sys.exit("The k-mer length is not valid. Please provide a integer k-mer value.")
            
        if kmer_length<1:    
            sys.exit("The k-mer length cannot be less than 1.")
        # if isinstance(fasta_string, str)==False:
            sys.exit("The fasta string contain non string value. It should contain only string.")
            
        fasta_string = fasta_string.upper()
              
        if len(set(list(fasta_string)))>4:
            sys.exit("The file has more than 4 unique value. Present model works only for 4 unique character.")
            
        if not (set(list(set(list(fasta_string)))).issubset(['G', 'T', 'A', 'C'])):
            sys.exit("The file charcater other than A, T, G, C. So we are exiting.")
       
            
        if kmer_length<1:    
                sys.exit("The k-mer length cannot be less than 1.")
                
        if chaos_game_kmer_array is None:
            chaos_game_kmer_array = self.chaos_game_representation_key(kmer_length)
                

        rows = np.power(2, kmer_length)
        
        fcgr_sequence = self.return_kmer_count(fasta_string, kmer_length=kmer_length)
        
        fcgr_sequence_lookup = {k.upper(): v for k, v in fcgr_sequence.items()}
        
        matrix2 = np.zeros((rows, rows))
        
        for (i, j), value in np.ndenumerate(chaos_game_kmer_array):
            upper_value = value.upper()
            if upper_value in fcgr_sequence_lookup:
                matrix2[i, j] = fcgr_sequence_lookup[upper_value]
                
        if pseudo_count==True:
            matrix2 = (matrix2 + np.ones((matrix2.shape[0],matrix2.shape[1])))
            

        df = pd.DataFrame(columns = ["kmer", "Freq"])
        df["kmer"] = chaos_game_kmer_array.ravel()
        df["Freq"] = matrix2.ravel()

        frequency_dictionary = {key: value for key, value in zip(df['kmer'], df['Freq'])}

        return frequency_dictionary
    
    
        
    def chaos_probabilistic_frequency_dictionary(self, fasta_string: str, kmer_length: int, chaos_game_kmer_array: np.array=None, pseudo_count = True):
        
        import numpy as np
        import sys
        import pandas as pd
        
        if isinstance(kmer_length, int)==False:    
            sys.exit("The k-mer length is not valid. Please provide a integer k-mer value.")
            
        if kmer_length<1:    
            sys.exit("The k-mer length cannot be less than 1.")
        # if isinstance(fasta_string, str)==False:
            sys.exit("The fasta string contain non string value. It should contain only string.")
            
        fasta_string = fasta_string.upper()
              
        if len(set(list(fasta_string)))>4:
            sys.exit("The file has more than 4 unique value. Present model works only for 4 unique character.")
            
        if not (set(list(set(list(fasta_string)))).issubset(['G', 'T', 'A', 'C'])):
            sys.exit("The file charcater other than A, T, G, C. So we are exiting.")
       
            
        if kmer_length<1:    
                sys.exit("The k-mer length cannot be less than 1.")
                
        if chaos_game_kmer_array is None:
            chaos_game_kmer_array = self.chaos_game_representation_key(kmer_length)
                

        rows = np.power(2, kmer_length)
        
        fcgr_sequence = self.return_kmer_count(fasta_string, kmer_length=kmer_length)
        
        fcgr_sequence_lookup = {k.upper(): v for k, v in fcgr_sequence.items()}
        
        matrix2 = np.zeros((rows, rows))
        
        for (i, j), value in np.ndenumerate(chaos_game_kmer_array):
            upper_value = value.upper()
            if upper_value in fcgr_sequence_lookup:
                matrix2[i, j] = fcgr_sequence_lookup[upper_value]
                
        if pseudo_count==True:
            matrix2 = (matrix2 + np.ones((matrix2.shape[0],matrix2.shape[1])))
            

        
        seq_fcgr_list = list()
        seq_fcgr_list.append(matrix2)

        prob_all_amr = [outer/sum(np.array(outer).ravel()) for outer in seq_fcgr_list]
        avg_prob_amr = np.sum(prob_all_amr, axis=0)/len(prob_all_amr)
        avg_prob_df = pd.DataFrame(columns = ["kmer", "Probability"])
        avg_prob_df["kmer"] = chaos_game_kmer_array.ravel()
        avg_prob_df["Probability"] = avg_prob_amr.ravel()

        avg_prob_dictionary = {key: value for key, value in zip(avg_prob_df['kmer'], avg_prob_df['Probability'])}

        return avg_prob_dictionary


        
    
    def return_kmer_index(self, kmer: str, kmer_length:int):
        
        import numpy as np
        import sys
        
        kmer = kmer.upper()
        
        if isinstance(kmer_length, int)==False:    
            sys.exit("The k-mer length is not valid. Please provide a integer k-mer value.")
            
        if kmer_length<1:    
            sys.exit("The k-mer length cannot be less than 1.")
            
        if len(set(list(kmer)))>4:
            sys.exit("The kmer has more than 4 unique value. Present model works only for 4 unique character.")
            
        if not (set(list(set(list(kmer)))).issubset(['G', 'T', 'A', 'C'])):
            sys.exit("The kmer has charcater other than A, T, G, C. So we are exiting.")
            
        if kmer_length!=len(kmer):    
            sys.exit("The length of kmer and the query length mismatch. Both should be of same length.")
            
        
        chaos_game_kmer_array =  self.chaos_game_representation_key(kmer_length = kmer_length)
    
        indices = np.where(chaos_game_kmer_array == kmer)
        index_of_string = (indices[0][0], indices[1][0])
    
        # print("The index kmer {a} with kmer size {c} is {b}.".format(a= kmer, b = index_of_string, c = kmer_length))
    
        return index_of_string

    def return_kmer_at_index(self, kmer_length:int, tuple_index : tuple):
        import sys
        import numpy as np
        
        if tuple_index[0]> np.power(2, kmer_length) or tuple_index[1]> np.power(2, kmer_length):
            sys.exit("The row/ column index is out of the fcgr matrix.")

        chaos_game_kmer_array =  self.chaos_game_representation_key(kmer_length = kmer_length)
        print("The kmer at index {a} with kmer size {c} is {b}.".format(a= tuple_index, b = chaos_game_kmer_array[tuple_index], c = kmer_length))
        return chaos_game_kmer_array[tuple_index]
    
    
    def find_kmers_indices(self, seq:str, k:int)->dict[str:list[int]]:
        """Function to return all the k-mers in a sequence and their positions"""
        seq = seq.upper()
        if k > len(seq):
            raise ValueError('k cannot be greater than the length of the sequence')
        for prot in seq:
            if prot not in ['A', 'C', 'G', 'T']:
                raise ValueError('Invalid sequence')
        k_mers = {}
        for i in range(len(seq)-k+1):
            k_mer = seq[i:i+k]
            if k_mer not in k_mers:
                k_mers[k_mer] = [i]
            else:
                k_mers[k_mer].append(i)
        return k_mers
    
    
    def return_kmer_count_individual(self, key_name: str, fasta_content: str):
        
        kmer_length = len(key_name)
        count = 0
        
        for i in range(len(fasta_content)- kmer_length + 1):
            
            if (fasta_content[i: i + kmer_length]==key_name):
                 count = count + 1
                 
        return count
    
    
    

    


    
   
        
    
    
